﻿using BusinessLogics;
using System;

namespace RegistrationConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            RegisterDetails:
            Console.WriteLine("Register user details quickly ... ");
            try
            {
                RegistrationProcess process = new RegistrationProcess();
                if (process.RegisterUser(out string message))
                {
                    Console.WriteLine("Registration is successfully done. Thank you !!");
                    Console.WriteLine(Environment.NewLine);
                    Console.WriteLine("Please press on Enter to register a new user...");
                    Console.ReadLine();               
                    goto RegisterDetails;
                }
                else
                {
                    if (String.IsNullOrWhiteSpace(message))
                    {
                        message = "Some ERROR encountered while processing the request !!";
                    }
                    Console.WriteLine(message);
                    Console.WriteLine(Environment.NewLine);
                    Console.WriteLine("Please press on Enter to register a new user...");
                    Console.ReadLine();
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine($"Exception - {ex.Message}  encountered while processing the request !!");
                Console.ReadLine();
            }
        }
    }
}
