﻿using System;
using static BusinessLogics.CommonEntities;
using static BusinessLogics.CommonEntities.PersonDetails;

namespace BusinessLogics
{
    /// <summary>
    /// This class handles all the registration related logics
    /// </summary>
    public class RegistrationProcess
    {
        /// <summary>
        /// private member to hold businesslogic handler
        /// </summary>
        private BusinessLogic businessLogic = new BusinessLogic();

        /// <summary>
        /// This method create user details, valodate age and check marrital status and register user.
        /// </summary>
        /// <param name="message">Returns failure message</param>
        /// <returns>returns true if the execution happens happily</returns>
        public bool RegisterUser(out string message)
        {
            bool isSuccess = false;
            message = string.Empty;
            //Create user details
            PersonDetails userDetails= businessLogic?.CreateUser("user");

            //Validate the age criteria of user
            IsAgeAuthorised isAgeAuthorised = businessLogic.ValidateAge(userDetails?.DateOfBirth, out message);
            if (isAgeAuthorised != IsAgeAuthorised.Authorised)
            {
                return isSuccess;
            }

            //Check and update the marrital status of the user
            if(!businessLogic.CheckAndUpdateMaritalStatus(ref userDetails))
            {
                message = "Some ERROR occurred while Checking and updating marital status !!";
            }

            //Save the user info to common file
            if (businessLogic.SavePeopleInfo(userDetails?.InfoToSave))
            {
                isSuccess = true;
            }
            else
            {
                message="Some ERROR occurred while processing !!";
            }
            return isSuccess;
        }
    }
}
