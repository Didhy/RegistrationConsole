﻿using BusinessLogics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistrationConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Register user details quickly ... ");
            try
            {
                RegistrationProcess process = new RegistrationProcess();
                if (process.RegisterUser(out string message))
                {
                    Console.WriteLine("Registration is successfully done. Thank you !!");
                    Console.ReadLine();

                }
                else
                {
                    if (String.IsNullOrWhiteSpace(message))
                    {
                        message = "Some ERROR encountered while processing the request !!";
                    }
                    Console.WriteLine(message);
                    Console.ReadLine();
                }
            }
            catch
            {
                Console.WriteLine("Some ERROR encountered while processing the request !!");
                Console.ReadLine();
            }
        }
    }
}
