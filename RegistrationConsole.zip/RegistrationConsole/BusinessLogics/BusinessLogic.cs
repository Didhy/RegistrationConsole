﻿using Newtonsoft.Json;
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using static BusinessLogics.CommonEntities;
using static BusinessLogics.CommonEntities.PersonDetails;

namespace BusinessLogics
{
    /// <summary>
    /// This class holds all the business logic processings required
    /// </summary>
    public class BusinessLogic
    {
        #region PublicMethods
        /// <summary>
        /// Save the people information to a common file
        /// </summary>
        /// <param name="personDetails"> Holds user details seperated by "|"</param>
        /// <returns>return true if successfully wrote to the file</returns>
        public bool SavePeopleInfo(string personDetails)
        {
            bool isSaved = false;
            if ((!String.IsNullOrWhiteSpace(personDetails)))
            {
                if (!CheckPathExistance(CommonEntities.GeneralPathInfo + CommonEntities.GeneralFileInfo))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(CommonEntities.GeneralPathInfo + CommonEntities.GeneralFileInfo));

                }
                using (StreamWriter txt = File.AppendText(CommonEntities.GeneralPathInfo + CommonEntities.GeneralFileInfo))
                {
                    txt.WriteLineAsync(personDetails);
                    txt.Close();
                    isSaved = true;
                }
            }
            return isSaved;
        }

        /// <summary>
        /// Save the life oartner information to a specific file
        /// </summary>
        /// <param name="personDetails"> Holds life partner details as json</param>
        /// <returns>return true if successfully wrote to the file</returns>
        public bool SaveLifePartnerInfo(PersonDetails personDetails)
        {
            bool isSaved = false;
            if (null != personDetails)
            {
                bool needTowrite = true;
                if (!CheckPathExistance(personDetails?.Status?.SavedPath))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(personDetails?.Status?.SavedPath));
                }
                else
                {
                    if (DoesSameUserExist(personDetails?.Status?.SavedPath))
                    {
                        needTowrite = false;
                    }
                }
                if (needTowrite)
                {
                    using (StreamWriter txt = File.AppendText(personDetails?.Status?.SavedPath))
                    {
                        txt.WriteLineAsync(JsonConvert.SerializeObject(personDetails));
                        txt.Close();
                        isSaved = true;
                    }
                }
            }
            else
            {
                Console.WriteLine("Some ERROR occurred while processing !!");

            }
            return isSaved;
        }

        /// <summary>
        /// Check whether user is married or not and update life partner information accordingly
        /// </summary>
        /// <param name="userDetails"> returns the updated usrdetails with marrital status</param>
        public void CheckAndUpdateMaritalStatus(ref PersonDetails userDetails)
        {
            CheckState:
            Console.WriteLine("Are you Married? ( Provide Y/N )");
            String married = Console.ReadLine();
            if (ValidateYesOrNo(married))
            {
                if (married.Equals("Y", StringComparison.OrdinalIgnoreCase))
                {
                    PersonDetails partnerDetails = CreateUser("your life partner's");
                    partnerDetails.Status.MarriageInfo = MariatalStatus.Married;
                    MarriageStatus mariatalStatus = new MarriageStatus(partnerDetails);
                    userDetails.Status = mariatalStatus;
                    userDetails.Status.SavedPath = $"{CommonEntities.GeneralPathInfo + CommonEntities.SpecificFolder + userDetails?.FirstName} - {userDetails?.Status?.LifePartnerInfo?.FirstName}.txt";
                    userDetails.InfoToSave = userDetails?.FirstName + "|" + userDetails?.SurName + "|" + userDetails?.DateOfBirth + "|" + userDetails?.Status?.MarriageInfo + "|" + userDetails?.Status?.SavedPath;

                    if (!SaveLifePartnerInfo(userDetails))
                    {
                        Console.WriteLine("Some ERROR occurred while processing !!");
                    }

                }
                else
                {
                    userDetails.InfoToSave = userDetails?.FirstName + "|" + userDetails?.SurName + "|" + userDetails?.DateOfBirth + "|" + userDetails?.Status?.MarriageInfo + "| null";

                }
            }
            else
            {
                goto CheckState;
            }
        }

        /// <summary>
        /// Create the user with first name , sur name and dob
        /// </summary>
        /// <param name="person"> Holds the type of user for whom data is requested</param>
        /// <returns>PersonDetails object with user information retrieved</returns>
        public PersonDetails CreateUser(string person)
        {
            GetFirstName:
            Console.WriteLine($"Please provide valid {person} First name : ");
            String userFirstName = Console.ReadLine();
            if (!ValidateInput(userFirstName))
            {
                goto GetFirstName;
            }
            
            GetSurname:
            Console.WriteLine($"Please provide valid {person} Sur name : ");
            String userSurName = Console.ReadLine();
            if (!ValidateInput(userSurName))
            {
                goto GetSurname;
            }

            GetDob:
            Console.WriteLine($"Please provide valid {person} date of birth (in yyyyMMdd format): ");
            String userDateOfBirth = Console.ReadLine();
            if (!ValidateDateFormat(userDateOfBirth))
            {
                goto GetDob;
            }
            PersonDetails userDetails = new PersonDetails(userFirstName, userSurName, userDateOfBirth);
            return userDetails;
        }

        /// <summary>
        /// Validate Age criteria based on business logic
        /// </summary>
        /// <param name="dob">Date of birth</param>
        /// <param name="message"> failure message</param>
        /// <returns>Return whether user is authorised or not based on business logic</returns>
        public IsAgeAuthorised ValidateAge(String dob, out string message)
        {
            IsAgeAuthorised isAgeAuthorised = IsAgeAuthorised.FailedToValidate;
            message = string.Empty;
            try
            {
                if (!String.IsNullOrWhiteSpace(dob))
                {
                    DateTime dobDateTime = DateTime.ParseExact(dob, @"yyyyMMdd", CultureInfo.InvariantCulture);
                    if (int.TryParse(dobDateTime.ToString(@"yyyyMMdd", CultureInfo.InvariantCulture), out int dobInfo))
                    {
                        if (int.TryParse(DateTime.Now.ToString(@"yyyyMMdd", CultureInfo.InvariantCulture), out int now))
                        {
                            int age = (now - dobInfo) / 10000;
                            if (age < 16)
                            {//user under 16 are not authorised for registration
                                isAgeAuthorised = IsAgeAuthorised.NotAuthorised;
                                message = "Sorry !! You are not authorised to register.";
                                return isAgeAuthorised;
                            }
                            else if (age < 18)
                            {//user under 18 and higher to 16 need authorisation from parents
                                isAgeAuthorised = IsAgeAuthorised.NeedAuthorisation;
                                Console.WriteLine("Please share parent's Authentication Y/N : ");
                                string response = Console.ReadLine();
                                if (response != "Y")
                                {
                                    message = "Sorry !! You are not authorised to register.";
                                    return isAgeAuthorised;
                                }
                                else
                                {
                                    isAgeAuthorised = IsAgeAuthorised.Authorised;
                                }
                            }
                            else
                            {//user above 18 are authorised for registartion
                                isAgeAuthorised = IsAgeAuthorised.Authorised;
                            }
                        }
                        else
                        {
                            message = "Failed to process date time now !!";
                        }
                    }
                    else
                    {
                        message = "Failed to process date of birth !!";
                    }
                }
                else
                {
                    message = "Date of birth value got empty !!";
                }
            }
            catch
            {
                message = "Some Error occurred while processing !!";
            }
            return isAgeAuthorised;
        }

        #endregion

        #region PrivateMethods

        /// <summary>
        /// Checks whether the same user exist
        /// </summary>
        /// <param name="savedPath">user saved path</param>
        /// <returns>returns true if same user exists</returns>
        private bool DoesSameUserExist(string savedPath)
        {
            bool isExist = false;
            //TBD
            //Need to check whether the user is already existing based on name and dob

            return isExist;
        }
        /// <summary>
        /// Validate the date format
        /// </summary>
        /// <param name="userDateOfBirth">date of birth</param>
        /// <returns>returns true if format is valid</returns>
        private bool ValidateDateFormat(string userDateOfBirth)
        {
            bool isValidate = false;
            
            if(DateTime.TryParseExact(userDateOfBirth, @"yyyyMMdd", CultureInfo.InvariantCulture,DateTimeStyles.AdjustToUniversal,out DateTime value))
            {
                isValidate = true;
            }
            return isValidate;
        }

        /// <summary>
        /// Validate the input string is null or empty
        /// </summary>
        /// <param name="info">input string</param>
        /// <returns>returns true if not null or empty or whitespace</returns>
        private bool ValidateInput(string info)
        {
            bool isValidate = false;
            if (!String.IsNullOrWhiteSpace(info) && !info.Any(c => char.IsDigit(c)))
            {
                isValidate = true;
            }
            return isValidate;
        }
        /// <summary>
        /// Validate the input string is yes or no
        /// </summary>
        /// <param name="info">input string</param>
        /// <returns>returns true input was either yes or no</returns>
        private bool ValidateYesOrNo(string info)
        {
            bool isValidate = false;
            if (!String.IsNullOrWhiteSpace(info) && !info.Any(c => char.IsDigit(c)))
            {
                if (info.Equals("Yes", StringComparison.OrdinalIgnoreCase) || info.Equals("No", StringComparison.OrdinalIgnoreCase)
                    || info.Equals("Y", StringComparison.OrdinalIgnoreCase) || info.Equals("N", StringComparison.OrdinalIgnoreCase))
                {
                    isValidate = true;
                }
            }
            return isValidate;
        }

        #endregion

    }
}
