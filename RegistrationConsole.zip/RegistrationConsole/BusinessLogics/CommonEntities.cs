﻿using System;
using System.IO;

namespace BusinessLogics
{
    /// <summary>
    /// This is a common class used accross the project solution
    /// </summary>
    public class CommonEntities
    {
        #region CommonEntities
        /// <summary>
        /// It holds all the information about the person
        /// </summary>
        public class PersonDetails
        {
            private MarriageStatus status;

            public PersonDetails(string userFirstName, string userSurName, string userDateOfBirth)
            {
                FirstName = userFirstName;
                SurName = userSurName;
                DateOfBirth = userDateOfBirth;
            }

            public String FirstName { get; private set; }
            public String SurName { get; private set; }
            public String DateOfBirth { get; private set; }
            public String InfoToSave { get; set; }
            public MarriageStatus Status { get; set; } = new MarriageStatus();
            public class MarriageStatus
            {
                public MariatalStatus MarriageInfo { get;  set; }

                public PersonDetails LifePartnerInfo { get; private set; }
                public String SavedPath { get; set; }
                public string InfoToSave { get; }

                public MarriageStatus(PersonDetails lifePartnerInfo=null)
                {
                    MarriageInfo = MariatalStatus.Single;
                    if (lifePartnerInfo != null)
                    {
                        MarriageInfo = MariatalStatus.Married;
                        LifePartnerInfo = lifePartnerInfo;
                    }
                }

            }

           
        }
        #endregion

        #region Enum
        /// <summary>
        /// Holds the marital status of the person
        /// </summary>
        public enum MariatalStatus
        {
            Single ,
            Married
        }

        /// <summary>
        /// Holds the Age validation types
        /// </summary>
        public enum IsAgeAuthorised
        {
            FailedToValidate,
            NotAuthorised,
            NeedAuthorisation,
            Authorised

        }
        #endregion

        #region StaticArea
        public const string GeneralPathInfo= "C:\\RegistrationConsole\\";
        public const string GeneralFileInfo = "main\\People.txt";
        public const string SpecificFolder = "PartnerInfo\\";

        public static bool CheckPathExistance(string path)
        {
            bool isExist = true;
            try
            {
                if (!File.Exists(path) && !Directory.Exists(Path.GetDirectoryName(path)))
                {
                    isExist = false;
                }
            }
            catch
            {
                isExist = false;
            }
            return isExist;
        }
        #endregion
    }
}
